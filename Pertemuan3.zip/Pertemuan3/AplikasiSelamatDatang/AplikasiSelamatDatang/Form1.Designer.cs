﻿namespace AplikasiSelamatDatang
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblKeterangan = new Label();
            btnKeterangan1 = new Button();
            btnKeterangan2 = new Button();
            SuspendLayout();
            // 
            // lblKeterangan
            // 
            lblKeterangan.AutoSize = true;
            lblKeterangan.ForeColor = Color.Red;
            lblKeterangan.Location = new Point(255, 178);
            lblKeterangan.Name = "lblKeterangan";
            lblKeterangan.Size = new Size(275, 25);
            lblKeterangan.TabIndex = 0;
            lblKeterangan.Text = "Selamat Datang di Pemrograman";
            lblKeterangan.Click += label1_Click;
            // 
            // btnKeterangan1
            // 
            btnKeterangan1.Location = new Point(171, 254);
            btnKeterangan1.Name = "btnKeterangan1";
            btnKeterangan1.Size = new Size(149, 34);
            btnKeterangan1.TabIndex = 1;
            btnKeterangan1.Text = "Keterangan 1";
            btnKeterangan1.UseVisualStyleBackColor = true;
            btnKeterangan1.Click += button1_Click;
            // 
            // btnKeterangan2
            // 
            btnKeterangan2.Location = new Point(470, 254);
            btnKeterangan2.Name = "btnKeterangan2";
            btnKeterangan2.Size = new Size(142, 34);
            btnKeterangan2.TabIndex = 2;
            btnKeterangan2.Text = "Keterangan 2";
            btnKeterangan2.UseVisualStyleBackColor = true;
            btnKeterangan2.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnKeterangan2);
            Controls.Add(btnKeterangan1);
            Controls.Add(lblKeterangan);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblKeterangan;
        private Button btnKeterangan1;
        private Button btnKeterangan2;
    }
}