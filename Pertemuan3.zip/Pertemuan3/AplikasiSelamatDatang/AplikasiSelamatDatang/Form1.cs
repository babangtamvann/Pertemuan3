namespace AplikasiSelamatDatang
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblKeterangan.Text = "Selamat Datang di Pemrograman";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblKeterangan.Text = "Begitu mudahnya membuat aplikasi berbasis windows";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}