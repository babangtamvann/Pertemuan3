﻿namespace TugasTiga1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNIM = new System.Windows.Forms.Label();
            this.textBoxNama = new System.Windows.Forms.Label();
            this.textBoxKelas = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxNIM
            // 
            this.textBoxNIM.AutoSize = true;
            this.textBoxNIM.Location = new System.Drawing.Point(97, 69);
            this.textBoxNIM.Name = "textBoxNIM";
            this.textBoxNIM.Size = new System.Drawing.Size(46, 20);
            this.textBoxNIM.TabIndex = 0;
            this.textBoxNIM.Text = "NIM :";
            // 
            // textBoxNama
            // 
            this.textBoxNama.AutoSize = true;
            this.textBoxNama.Location = new System.Drawing.Point(92, 124);
            this.textBoxNama.Name = "textBoxNama";
            this.textBoxNama.Size = new System.Drawing.Size(59, 20);
            this.textBoxNama.TabIndex = 1;
            this.textBoxNama.Text = "Nama :";
            // 
            // textBoxKelas
            // 
            this.textBoxKelas.AutoSize = true;
            this.textBoxKelas.Location = new System.Drawing.Point(92, 187);
            this.textBoxKelas.Name = "textBoxKelas";
            this.textBoxKelas.Size = new System.Drawing.Size(56, 20);
            this.textBoxKelas.TabIndex = 2;
            this.textBoxKelas.Text = "Kelas :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(278, 250);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 31);
            this.button1.TabIndex = 3;
            this.button1.Text = "Tampilkan";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(455, 250);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 31);
            this.button2.TabIndex = 4;
            this.button2.Text = "Kosongkan";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxKelas);
            this.Controls.Add(this.textBoxNama);
            this.Controls.Add(this.textBoxNIM);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label textBoxNIM;
        private System.Windows.Forms.Label textBoxNama;
        private System.Windows.Forms.Label textBoxKelas;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

